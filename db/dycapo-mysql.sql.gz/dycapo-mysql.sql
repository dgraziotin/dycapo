# Sequel Pro dump
# Version 2492
# http://code.google.com/p/sequel-pro
#
# Host: 127.0.0.1 (MySQL 5.1.48)
# Database: dycapo
# Generation Time: 2010-09-02 15:35:00 +0200
# ************************************************************

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table auth_group
# ------------------------------------------------------------

DROP TABLE IF EXISTS `auth_group`;

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table auth_group_permissions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `auth_group_permissions`;

CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`,`permission_id`),
  KEY `auth_group_permissions_bda51c3c` (`group_id`),
  KEY `auth_group_permissions_1e014c8f` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table auth_message
# ------------------------------------------------------------

DROP TABLE IF EXISTS `auth_message`;

CREATE TABLE `auth_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `message` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `auth_message_fbfc09f1` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table auth_permission
# ------------------------------------------------------------

DROP TABLE IF EXISTS `auth_permission`;

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`,`codename`),
  KEY `auth_permission_e4470c6e` (`content_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=57 DEFAULT CHARSET=latin1;

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` (`id`,`name`,`content_type_id`,`codename`)
VALUES
	(1,'Can add permission',1,'add_permission'),
	(2,'Can change permission',1,'change_permission'),
	(3,'Can delete permission',1,'delete_permission'),
	(4,'Can add group',2,'add_group'),
	(5,'Can change group',2,'change_group'),
	(6,'Can delete group',2,'delete_group'),
	(7,'Can add user',3,'add_user'),
	(8,'Can change user',3,'change_user'),
	(9,'Can delete user',3,'delete_user'),
	(10,'Can add message',4,'add_message'),
	(11,'Can change message',4,'change_message'),
	(12,'Can delete message',4,'delete_message'),
	(13,'Can add content type',5,'add_contenttype'),
	(14,'Can change content type',5,'change_contenttype'),
	(15,'Can delete content type',5,'delete_contenttype'),
	(16,'Can add session',6,'add_session'),
	(17,'Can change session',6,'change_session'),
	(18,'Can delete session',6,'delete_session'),
	(19,'Can add site',7,'add_site'),
	(20,'Can change site',7,'change_site'),
	(21,'Can delete site',7,'delete_site'),
	(22,'Can add log entry',8,'add_logentry'),
	(23,'Can change log entry',8,'change_logentry'),
	(24,'Can delete log entry',8,'delete_logentry'),
	(25,'Can add nonce',9,'add_nonce'),
	(26,'Can change nonce',9,'change_nonce'),
	(27,'Can delete nonce',9,'delete_nonce'),
	(28,'Can add consumer',10,'add_consumer'),
	(29,'Can change consumer',10,'change_consumer'),
	(30,'Can delete consumer',10,'delete_consumer'),
	(31,'Can add token',11,'add_token'),
	(32,'Can change token',11,'change_token'),
	(33,'Can delete token',11,'delete_token'),
	(34,'Can add location',12,'add_location'),
	(35,'Can change location',12,'change_location'),
	(36,'Can delete location',12,'delete_location'),
	(37,'Can add modality',13,'add_modality'),
	(38,'Can change modality',13,'change_modality'),
	(39,'Can delete modality',13,'delete_modality'),
	(40,'Can add preferences',14,'add_preferences'),
	(41,'Can change preferences',14,'change_preferences'),
	(42,'Can delete preferences',14,'delete_preferences'),
	(43,'Can add trip',15,'add_trip'),
	(44,'Can change trip',15,'change_trip'),
	(45,'Can delete trip',15,'delete_trip'),
	(46,'Can add participation',16,'add_participation'),
	(47,'Can change participation',16,'change_participation'),
	(48,'Can delete participation',16,'delete_participation'),
	(49,'Can add person',17,'add_person'),
	(50,'Can change person',17,'change_person'),
	(51,'Can delete person',17,'delete_person'),
	(52,'Can perform XML-RPC to Dycapo',17,'can_xmlrpc'),
	(53,'Can register to the System using XML-RPC',17,'can_register'),
	(54,'Can add search',18,'add_search'),
	(55,'Can change search',18,'change_search'),
	(56,'Can delete search',18,'delete_search');

/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table auth_user
# ------------------------------------------------------------

DROP TABLE IF EXISTS `auth_user`;

CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(75) NOT NULL,
  `password` varchar(128) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `last_login` datetime NOT NULL,
  `date_joined` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` (`id`,`username`,`first_name`,`last_name`,`email`,`password`,`is_staff`,`is_active`,`is_superuser`,`last_login`,`date_joined`)
VALUES
	(1,'admin','','','admin@admins.com','sha1$7604d$d16f0b0cf9e07fabfa5d0bdcce09617c9f67037f',1,1,1,'2010-09-02 15:30:40','2010-09-02 15:30:40'),
	(2,'blahhhh','','','blah@blah.com','sha1$8501b$94146d5c9d3cbc45bae36356f169935766cecbc9',0,1,0,'2010-09-02 15:31:15','2010-09-02 15:31:15'),
	(3,'driver1','','','driver@drivers.com','sha1$4854f$116965b7983d465e54cfc7ec103219e893e20309',0,1,0,'2010-09-02 15:31:15','2010-09-02 15:31:15'),
	(4,'angela','','','angela@archenemy.com','sha1$0e2d4$f1b6186a8039260de80ead530c4431d3f5ecd042',0,1,0,'2010-09-02 15:31:15','2010-09-02 15:31:15'),
	(5,'rider1','','','rider@riders.com','sha1$3103f$ce0537c5df93b7ae8d68a6fb21c551e3fc2b044e',0,1,0,'2010-09-02 15:31:32','2010-09-02 15:31:32'),
	(6,'dio','','','dio@ronniejamesdio.com','sha1$7f40a$9f40df7f12dd074eeeb6ac2c0459508a65016c88',0,1,0,'2010-09-02 15:34:37','2010-09-02 15:34:37'),
	(7,'rob','','','rob@judaspriest.com','sha1$a3e0a$ade5ce5f66ba40a944de8ce6fb349f7dff8167d1',0,1,0,'2010-09-02 15:34:37','2010-09-02 15:34:37'),
	(8,'ozzy','','','ozzy@acdcd.com','sha1$6222b$b1ba246622c98d1f6d120e2bac6b2d98c2ba9eb9',0,1,0,'2010-09-02 15:34:37','2010-09-02 15:34:37'),
	(9,'bruce','','','bruce@ironmaiden.com','sha1$d26ac$8b2bed310280b7880f4499df70f31509675fab08',0,1,0,'2010-09-02 15:34:37','2010-09-02 15:34:37');

/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table auth_user_groups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `auth_user_groups`;

CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`group_id`),
  KEY `auth_user_groups_fbfc09f1` (`user_id`),
  KEY `auth_user_groups_bda51c3c` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table auth_user_user_permissions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `auth_user_user_permissions`;

CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`permission_id`),
  KEY `auth_user_user_permissions_fbfc09f1` (`user_id`),
  KEY `auth_user_user_permissions_1e014c8f` (`permission_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
INSERT INTO `auth_user_user_permissions` (`id`,`user_id`,`permission_id`)
VALUES
	(1,2,52),
	(2,3,52),
	(3,4,52),
	(4,5,52),
	(5,6,52),
	(6,7,52),
	(7,8,52),
	(8,9,52);

/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table django_admin_log
# ------------------------------------------------------------

DROP TABLE IF EXISTS `django_admin_log`;

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_fbfc09f1` (`user_id`),
  KEY `django_admin_log_e4470c6e` (`content_type_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table django_content_type
# ------------------------------------------------------------

DROP TABLE IF EXISTS `django_content_type`;

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `app_label` (`app_label`,`model`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` (`id`,`name`,`app_label`,`model`)
VALUES
	(1,'permission','auth','permission'),
	(2,'group','auth','group'),
	(3,'user','auth','user'),
	(4,'message','auth','message'),
	(5,'content type','contenttypes','contenttype'),
	(6,'session','sessions','session'),
	(7,'site','sites','site'),
	(8,'log entry','admin','logentry'),
	(9,'nonce','piston','nonce'),
	(10,'consumer','piston','consumer'),
	(11,'token','piston','token'),
	(12,'location','server','location'),
	(13,'modality','server','modality'),
	(14,'preferences','server','preferences'),
	(15,'trip','server','trip'),
	(16,'participation','server','participation'),
	(17,'person','server','person'),
	(18,'search','server','search');

/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table django_session
# ------------------------------------------------------------

DROP TABLE IF EXISTS `django_session`;

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime NOT NULL,
  PRIMARY KEY (`session_key`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table django_site
# ------------------------------------------------------------

DROP TABLE IF EXISTS `django_site`;

CREATE TABLE `django_site` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

LOCK TABLES `django_site` WRITE;
/*!40000 ALTER TABLE `django_site` DISABLE KEYS */;
INSERT INTO `django_site` (`id`,`domain`,`name`)
VALUES
	(1,'example.com','example.com');

/*!40000 ALTER TABLE `django_site` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table piston_consumer
# ------------------------------------------------------------

DROP TABLE IF EXISTS `piston_consumer`;

CREATE TABLE `piston_consumer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `key` varchar(18) NOT NULL,
  `secret` varchar(32) NOT NULL,
  `status` varchar(16) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `piston_consumer_fbfc09f1` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table piston_nonce
# ------------------------------------------------------------

DROP TABLE IF EXISTS `piston_nonce`;

CREATE TABLE `piston_nonce` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token_key` varchar(18) NOT NULL,
  `consumer_key` varchar(18) NOT NULL,
  `key` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table piston_token
# ------------------------------------------------------------

DROP TABLE IF EXISTS `piston_token`;

CREATE TABLE `piston_token` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(18) NOT NULL,
  `secret` varchar(32) NOT NULL,
  `verifier` varchar(10) NOT NULL,
  `token_type` int(11) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `is_approved` tinyint(1) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `consumer_id` int(11) NOT NULL,
  `callback` varchar(255) DEFAULT NULL,
  `callback_confirmed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `piston_token_fbfc09f1` (`user_id`),
  KEY `piston_token_6565fc20` (`consumer_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table server_location
# ------------------------------------------------------------

DROP TABLE IF EXISTS `server_location`;

CREATE TABLE `server_location` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(255) NOT NULL,
  `street` varchar(255) NOT NULL,
  `point` varchar(50) NOT NULL,
  `country` varchar(2) NOT NULL,
  `region` varchar(255) NOT NULL,
  `town` varchar(255) NOT NULL,
  `postcode` int(10) unsigned NOT NULL,
  `subregion` varchar(255) NOT NULL,
  `georss_point` varchar(255) NOT NULL,
  `georss_point_latitude` double NOT NULL,
  `georss_point_longitude` double NOT NULL,
  `offset` int(10) unsigned NOT NULL,
  `recurs` varchar(255) NOT NULL,
  `days` varchar(255) NOT NULL,
  `leaves` datetime NOT NULL,
  `href` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `server_location_fa8e2538` (`point`),
  KEY `server_location_e2a5c0f` (`georss_point`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table server_modality
# ------------------------------------------------------------

DROP TABLE IF EXISTS `server_modality`;

CREATE TABLE `server_modality` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kind` varchar(255) NOT NULL,
  `capacity` int(10) unsigned NOT NULL,
  `vacancy` int(11) NOT NULL,
  `make` varchar(255) NOT NULL,
  `model_name` varchar(255) NOT NULL,
  `year` int(10) unsigned NOT NULL,
  `color` varchar(255) NOT NULL,
  `lic` varchar(255) NOT NULL,
  `cost` double NOT NULL,
  `person_id` int(11) DEFAULT NULL,
  `href` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `server_modality_21b911c5` (`person_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table server_participation
# ------------------------------------------------------------

DROP TABLE IF EXISTS `server_participation`;

CREATE TABLE `server_participation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `author_id` int(11) NOT NULL,
  `trip_id` int(11) NOT NULL,
  `role` varchar(6) NOT NULL,
  `requested` tinyint(1) NOT NULL,
  `requested_timestamp` datetime DEFAULT NULL,
  `requested_position_id` int(11) DEFAULT NULL,
  `requested_deleted` tinyint(1) NOT NULL,
  `requested_deleted_timestamp` datetime DEFAULT NULL,
  `requested_deleted_position_id` int(11) DEFAULT NULL,
  `accepted` tinyint(1) NOT NULL,
  `accepted_timestamp` datetime DEFAULT NULL,
  `accepted_position_id` int(11) DEFAULT NULL,
  `refused` tinyint(1) NOT NULL,
  `refused_timestamp` datetime DEFAULT NULL,
  `refused_position_id` int(11) DEFAULT NULL,
  `started` tinyint(1) NOT NULL,
  `started_timestamp` datetime DEFAULT NULL,
  `started_position_id` int(11) DEFAULT NULL,
  `finished` tinyint(1) NOT NULL,
  `finished_timestamp` datetime DEFAULT NULL,
  `finished_position_id` int(11) DEFAULT NULL,
  `href` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `author_id` (`author_id`,`trip_id`),
  KEY `server_participation_cc846901` (`author_id`),
  KEY `server_participation_ab5488a7` (`trip_id`),
  KEY `server_participation_6d876e44` (`requested_position_id`),
  KEY `server_participation_2140776e` (`requested_deleted_position_id`),
  KEY `server_participation_f0424aca` (`accepted_position_id`),
  KEY `server_participation_ead8a8be` (`refused_position_id`),
  KEY `server_participation_624bc54d` (`started_position_id`),
  KEY `server_participation_9edd96f9` (`finished_position_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table server_participation_locations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `server_participation_locations`;

CREATE TABLE `server_participation_locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `participation_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `participation_id` (`participation_id`,`location_id`),
  KEY `server_participation_locations_3c980c0e` (`participation_id`),
  KEY `server_participation_locations_319d859` (`location_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table server_person
# ------------------------------------------------------------

DROP TABLE IF EXISTS `server_person`;

CREATE TABLE `server_person` (
  `user_ptr_id` int(11) NOT NULL,
  `uri` varchar(200) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `age` int(10) unsigned NOT NULL,
  `gender` varchar(1) NOT NULL,
  `smoker` tinyint(1) NOT NULL,
  `blind` tinyint(1) NOT NULL,
  `deaf` tinyint(1) NOT NULL,
  `dog` tinyint(1) NOT NULL,
  `href` varchar(200) NOT NULL,
  PRIMARY KEY (`user_ptr_id`),
  UNIQUE KEY `phone` (`phone`),
  KEY `server_person_319d859` (`location_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

LOCK TABLES `server_person` WRITE;
/*!40000 ALTER TABLE `server_person` DISABLE KEYS */;
INSERT INTO `server_person` (`user_ptr_id`,`uri`,`phone`,`location_id`,`age`,`gender`,`smoker`,`blind`,`deaf`,`dog`,`href`)
VALUES
	(2,'','12345',NULL,0,'M',0,0,0,0,'http://127.0.0.1/api/persons/blahhhh/'),
	(3,'','123456',NULL,0,'M',0,0,0,0,'http://127.0.0.1/api/persons/driver1/'),
	(4,'','12345678901',NULL,0,'M',0,0,0,0,'http://127.0.0.1/api/persons/angela/'),
	(5,'','1234567',NULL,0,'M',0,0,0,0,'http://127.0.0.1/api/persons/rider1/'),
	(6,'','12345678',NULL,0,'M',0,0,0,0,'http://127.0.0.1/api/persons/dio/'),
	(7,'','123456789',NULL,0,'M',0,0,0,0,'http://127.0.0.1/api/persons/rob/'),
	(8,'','1234567890',NULL,0,'M',0,0,0,0,'http://127.0.0.1/api/persons/ozzy/'),
	(9,'','1234567801324',NULL,0,'M',0,0,0,0,'http://127.0.0.1/api/persons/bruce/');

/*!40000 ALTER TABLE `server_person` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table server_person_locations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `server_person_locations`;

CREATE TABLE `server_person_locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `person_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `person_id` (`person_id`,`location_id`),
  KEY `server_person_locations_21b911c5` (`person_id`),
  KEY `server_person_locations_319d859` (`location_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table server_preferences
# ------------------------------------------------------------

DROP TABLE IF EXISTS `server_preferences`;

CREATE TABLE `server_preferences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `age` varchar(50) NOT NULL,
  `nonsmoking` tinyint(1) NOT NULL,
  `gender` varchar(1) NOT NULL,
  `drive` tinyint(1) NOT NULL,
  `ride` tinyint(1) NOT NULL,
  `href` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table server_search
# ------------------------------------------------------------

DROP TABLE IF EXISTS `server_search`;

CREATE TABLE `server_search` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `published` datetime NOT NULL,
  `author_id` int(11) NOT NULL,
  `origin_id` int(11) NOT NULL,
  `destination_id` int(11) NOT NULL,
  `href` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `server_search_cc846901` (`author_id`),
  KEY `server_search_bd654448` (`origin_id`),
  KEY `server_search_90a09905` (`destination_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table server_trip
# ------------------------------------------------------------

DROP TABLE IF EXISTS `server_trip`;

CREATE TABLE `server_trip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `published` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `expires` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL,
  `author_id` int(11) NOT NULL,
  `modality_id` int(11) NOT NULL,
  `preferences_id` int(11) NOT NULL,
  `href` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `server_trip_87f258d4` (`expires`),
  KEY `server_trip_34d728db` (`active`),
  KEY `server_trip_cc846901` (`author_id`),
  KEY `server_trip_117d78a1` (`modality_id`),
  KEY `server_trip_2d9474d5` (`preferences_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table server_trip_locations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `server_trip_locations`;

CREATE TABLE `server_trip_locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trip_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `trip_id` (`trip_id`,`location_id`),
  KEY `server_trip_locations_ab5488a7` (`trip_id`),
  KEY `server_trip_locations_319d859` (`location_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;






/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
