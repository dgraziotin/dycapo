# Sequel Pro dump
# Version 2492
# http://code.google.com/p/sequel-pro
#
# Host: 127.0.0.1 (MySQL 5.1.48)
# Database: dycapo
# Generation Time: 2010-08-26 12:41:53 +0200
# ************************************************************

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table auth_group
# ------------------------------------------------------------

DROP TABLE IF EXISTS `auth_group`;

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table auth_group_permissions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `auth_group_permissions`;

CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`,`permission_id`),
  KEY `auth_group_permissions_bda51c3c` (`group_id`),
  KEY `auth_group_permissions_1e014c8f` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table auth_message
# ------------------------------------------------------------

DROP TABLE IF EXISTS `auth_message`;

CREATE TABLE `auth_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `message` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `auth_message_fbfc09f1` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;



# Dump of table auth_permission
# ------------------------------------------------------------

DROP TABLE IF EXISTS `auth_permission`;

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`,`codename`),
  KEY `auth_permission_e4470c6e` (`content_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=latin1;

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` (`id`,`name`,`content_type_id`,`codename`)
VALUES
	(1,'Can add permission',1,'add_permission'),
	(2,'Can change permission',1,'change_permission'),
	(3,'Can delete permission',1,'delete_permission'),
	(4,'Can add group',2,'add_group'),
	(5,'Can change group',2,'change_group'),
	(6,'Can delete group',2,'delete_group'),
	(7,'Can add user',3,'add_user'),
	(8,'Can change user',3,'change_user'),
	(9,'Can delete user',3,'delete_user'),
	(10,'Can add message',4,'add_message'),
	(11,'Can change message',4,'change_message'),
	(12,'Can delete message',4,'delete_message'),
	(13,'Can add content type',5,'add_contenttype'),
	(14,'Can change content type',5,'change_contenttype'),
	(15,'Can delete content type',5,'delete_contenttype'),
	(16,'Can add session',6,'add_session'),
	(17,'Can change session',6,'change_session'),
	(18,'Can delete session',6,'delete_session'),
	(19,'Can add site',7,'add_site'),
	(20,'Can change site',7,'change_site'),
	(21,'Can delete site',7,'delete_site'),
	(22,'Can add log entry',8,'add_logentry'),
	(23,'Can change log entry',8,'change_logentry'),
	(24,'Can delete log entry',8,'delete_logentry'),
	(25,'Can add nonce',9,'add_nonce'),
	(26,'Can change nonce',9,'change_nonce'),
	(27,'Can delete nonce',9,'delete_nonce'),
	(28,'Can add consumer',10,'add_consumer'),
	(29,'Can change consumer',10,'change_consumer'),
	(30,'Can delete consumer',10,'delete_consumer'),
	(31,'Can add token',11,'add_token'),
	(32,'Can change token',11,'change_token'),
	(33,'Can delete token',11,'delete_token'),
	(34,'Can add location',12,'add_location'),
	(35,'Can change location',12,'change_location'),
	(36,'Can delete location',12,'delete_location'),
	(37,'Can add modality',13,'add_modality'),
	(38,'Can change modality',13,'change_modality'),
	(39,'Can delete modality',13,'delete_modality'),
	(40,'Can add preferences',14,'add_preferences'),
	(41,'Can change preferences',14,'change_preferences'),
	(42,'Can delete preferences',14,'delete_preferences'),
	(43,'Can add trip',15,'add_trip'),
	(44,'Can change trip',15,'change_trip'),
	(45,'Can delete trip',15,'delete_trip'),
	(46,'Can add participation',16,'add_participation'),
	(47,'Can change participation',16,'change_participation'),
	(48,'Can delete participation',16,'delete_participation'),
	(49,'Can add person',17,'add_person'),
	(50,'Can change person',17,'change_person'),
	(51,'Can delete person',17,'delete_person'),
	(52,'Can perform XML-RPC to Dycapo',17,'can_xmlrpc'),
	(53,'Can register to the System using XML-RPC',17,'can_register');

/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table auth_user
# ------------------------------------------------------------

DROP TABLE IF EXISTS `auth_user`;

CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(75) NOT NULL,
  `password` varchar(128) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `last_login` datetime NOT NULL,
  `date_joined` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` (`id`,`username`,`first_name`,`last_name`,`email`,`password`,`is_staff`,`is_active`,`is_superuser`,`last_login`,`date_joined`)
VALUES
	(1,'admin','','','daniel.graziotin@acm.org','sha1$09b9d$fa9bcafa090a5bdee3f82e7f57aea6e5120eff77',1,1,1,'2010-08-26 12:37:22','2010-08-26 12:35:57'),
	(2,'register','REGISTER','REGISTER','REGISTER@REGISTER.com','sha1$cc836$1d0c30a50999df9bf33d7433b988e00b68203dd5',0,1,0,'2010-08-26 12:39:40','2010-08-26 12:37:28'),
	(3,'blahhhh','','','blah@blah.com','sha1$41456$1aa13c03a038ccd66c97cf902ce3989b7de3dcf2',0,1,0,'2010-08-26 12:38:28','2010-08-26 12:38:28'),
	(4,'driver1','','','driver@drivers.com','sha1$acf83$f52bb4b38cc18a0186c6aa783ca2750eb2e7e70f',0,1,0,'2010-08-26 12:39:45','2010-08-26 12:38:28'),
	(5,'rider1','','','rider@riders.com','sha1$c04bc$726637d969600001a02aae2df4acdd4069aee3d0',0,1,0,'2010-08-26 12:39:45','2010-08-26 12:38:28'),
	(6,'dio','','','dio@ronniejamesdio.com','sha1$e263e$6bb6694a95af3edd9ec281b603913ad425e0955d',0,1,0,'2010-08-26 12:39:39','2010-08-26 12:38:28'),
	(7,'rob','','','rob@judaspriest.com','sha1$3da5e$415872485a1c1d76de6eb8e4b30dc399735afcc5',0,1,0,'2010-08-26 12:39:39','2010-08-26 12:38:28'),
	(8,'ozzy','','','ozzy@acdcd.com','sha1$f46b1$8a083f8585d58f0299d4a2d756bcf10d07d775f1',0,1,0,'2010-08-26 12:39:45','2010-08-26 12:38:28'),
	(9,'bruce','','','bruce@ironmaiden.com','sha1$a48e8$f4229ad74254a7548ffcc87ecbf0e68f35708d5f',0,1,0,'2010-08-26 12:39:39','2010-08-26 12:38:28'),
	(10,'angela','','','angela@archenemy.com','sha1$0fa24$5c42bf921f32d629d38d6723226f9a9e08e589c0',0,1,0,'2010-08-26 12:39:39','2010-08-26 12:38:28');

/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table auth_user_groups
# ------------------------------------------------------------

DROP TABLE IF EXISTS `auth_user_groups`;

CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`group_id`),
  KEY `auth_user_groups_fbfc09f1` (`user_id`),
  KEY `auth_user_groups_bda51c3c` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table auth_user_user_permissions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `auth_user_user_permissions`;

CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`permission_id`),
  KEY `auth_user_user_permissions_fbfc09f1` (`user_id`),
  KEY `auth_user_user_permissions_1e014c8f` (`permission_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
INSERT INTO `auth_user_user_permissions` (`id`,`user_id`,`permission_id`)
VALUES
	(1,2,53),
	(2,3,52),
	(3,4,52),
	(4,5,52),
	(5,6,52),
	(6,7,52),
	(7,8,52),
	(8,9,52),
	(9,10,52);

/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table django_admin_log
# ------------------------------------------------------------

DROP TABLE IF EXISTS `django_admin_log`;

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_fbfc09f1` (`user_id`),
  KEY `django_admin_log_e4470c6e` (`content_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` (`id`,`action_time`,`user_id`,`content_type_id`,`object_id`,`object_repr`,`action_flag`,`change_message`)
VALUES
	(1,'2010-08-26 12:37:51',1,17,'2','register',1,'');

/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table django_content_type
# ------------------------------------------------------------

DROP TABLE IF EXISTS `django_content_type`;

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `app_label` (`app_label`,`model`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` (`id`,`name`,`app_label`,`model`)
VALUES
	(1,'permission','auth','permission'),
	(2,'group','auth','group'),
	(3,'user','auth','user'),
	(4,'message','auth','message'),
	(5,'content type','contenttypes','contenttype'),
	(6,'session','sessions','session'),
	(7,'site','sites','site'),
	(8,'log entry','admin','logentry'),
	(9,'nonce','piston','nonce'),
	(10,'consumer','piston','consumer'),
	(11,'token','piston','token'),
	(12,'location','server','location'),
	(13,'modality','server','modality'),
	(14,'preferences','server','preferences'),
	(15,'trip','server','trip'),
	(16,'participation','server','participation'),
	(17,'person','server','person');

/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table django_session
# ------------------------------------------------------------

DROP TABLE IF EXISTS `django_session`;

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime NOT NULL,
  PRIMARY KEY (`session_key`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` (`session_key`,`session_data`,`expire_date`)
VALUES
	('7ccf7690b3b4e0832275fa32c5badeb2','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigECdS4xOWJhYTUwOWQ0ODU3MDhk\nYTY0NDZjOTNlNzVhZGMxMQ==\n','2010-09-09 12:38:28'),
	('9cb2e8adb47940ff55643e9f23732f3d','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEBdS43ODI2YTQ1Mjk4MWZmMmUy\nMzVmZDQ0ZWM3OGUxZGE1ZA==\n','2010-09-09 12:37:22'),
	('84419ee53e33aa8088dfc50e1f4a1829','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigECdS4xOWJhYTUwOWQ0ODU3MDhk\nYTY0NDZjOTNlNzVhZGMxMQ==\n','2010-09-09 12:38:28'),
	('0104fd7212c5ef9bb465fc044b271a04','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigECdS4xOWJhYTUwOWQ0ODU3MDhk\nYTY0NDZjOTNlNzVhZGMxMQ==\n','2010-09-09 12:38:28'),
	('e116d8d797f9354acb1480883da1c63f','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigECdS4xOWJhYTUwOWQ0ODU3MDhk\nYTY0NDZjOTNlNzVhZGMxMQ==\n','2010-09-09 12:38:28'),
	('f6e22d3f6d6051a511339ae71fa22c32','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigECdS4xOWJhYTUwOWQ0ODU3MDhk\nYTY0NDZjOTNlNzVhZGMxMQ==\n','2010-09-09 12:38:28'),
	('1181e9a0d9485338924cdaa385cd9ebb','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigECdS4xOWJhYTUwOWQ0ODU3MDhk\nYTY0NDZjOTNlNzVhZGMxMQ==\n','2010-09-09 12:38:28'),
	('dbcd9d4087ed9a248ed9799634b87aac','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigECdS4xOWJhYTUwOWQ0ODU3MDhk\nYTY0NDZjOTNlNzVhZGMxMQ==\n','2010-09-09 12:38:28'),
	('eb5d5cb3201e86ebcdd9781dc525f090','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigECdS4xOWJhYTUwOWQ0ODU3MDhk\nYTY0NDZjOTNlNzVhZGMxMQ==\n','2010-09-09 12:38:28'),
	('a20f082e8d487008c3f454a74a045056','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigECdS4xOWJhYTUwOWQ0ODU3MDhk\nYTY0NDZjOTNlNzVhZGMxMQ==\n','2010-09-09 12:38:28'),
	('46d5b4f1516e34393a77393120e5d565','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:38:33'),
	('1d0af75f26a98c48d4024045c9a2f9d4','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:38:33'),
	('29b30c7f93a258243e67774bc8fce1d5','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:38:33'),
	('d4c1858d4cfde7ea6c28687d2cdc8968','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:38:33'),
	('1c84eebce1471155e32c8768898c334b','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:38:35'),
	('b7f33b38f5ee5cf37b3163f55243284c','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:38:35'),
	('2e0a9f4398257959106d0723e311c96c','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:38:40'),
	('9279d51e6bbe1105b4202d3b709fef70','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:38:40'),
	('c150cff01e3c1e4f35d797e625f986fb','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:38:41'),
	('639eaca21e98015f5c5bd395cc56faca','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:38:41'),
	('bfded462bd7a0b9d4fdbef6fb3bc18a4','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:38:41'),
	('be5d23d62ceb84608955cd0a3d915281','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:38:42'),
	('cce2fd89ce4034eac102a45d02711b5f','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:38:42'),
	('5747de4bdf82917b3d50573e08abb4d8','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:01'),
	('4cd55338fb4afe3c2e10085a1666291f','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:01'),
	('3ecd387f053313638a081a99bb217937','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:01'),
	('edee9d63911f9e0b4eb89bbd220b1e74','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:01'),
	('61a5ab043355885641524b8a2cc80623','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:01'),
	('d1e6c71db8c9eb6f11a1d46685e62684','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:01'),
	('31d3c63f2f76aa919414db8b73abeda2','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:01'),
	('90237c0dd7f16c4b57171c841070a539','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:01'),
	('d51c6c29bf2d878cb8baefebeecb65d3','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:01'),
	('d24d82c01d67ad2bd6a6fcb89103594c','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:05'),
	('8e826728b6538420a12f00c7bc789132','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:05'),
	('0c6f51ba02675ba7261dd637cceafb10','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:05'),
	('9131a8c0ba55f87e8f87751a0208b493','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:05'),
	('053fb256d6814a02b8629dc388de28ea','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:05'),
	('849f7495aa431fa42ef7a8faecdcec79','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:05'),
	('3e51a48dadc29c987994cc344bf4f1b9','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:05'),
	('7db095370dc4e372619e3c950e9525ae','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:05'),
	('e2c9a102158c8a0ea42346ba0a0b0887','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:05'),
	('a995b76eb9a5ba603925210d43bf555b','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:05'),
	('666376540ef845b1c653c2dd872e1155','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:05'),
	('569a8b1e52db47acf9149f3960b058df','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:06'),
	('10baab4724c2b28a774400c3ff12b6ab','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:06'),
	('866a7f208a2bfa53b20aada4622d324c','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:06'),
	('3c887dd58eb1d252d6aa458d7ccd19fa','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:06'),
	('78c5c169363dce1c091d08b087ffc5bc','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:07'),
	('c7c8aa791c23215deb0dd5dfa4355ace','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:07'),
	('946ed9e0e83a4bbb2426a5c0aeec2248','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:07'),
	('3b48406a20192a4ba7d310fc19711ebf','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:07'),
	('22359fbc8f2e3b65d23f819e70a3d106','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:08'),
	('39c8da7a5a9bcb53089caef8da878166','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:08'),
	('42d1db15b9b10be73e26a784658e3d33','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:08'),
	('7fce15aab57c13d06ac332e435122b44','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:09'),
	('d2945c3ddbdc8ece7cf494aeadc37817','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:09'),
	('56efebb06dd9f4443bb00443cd21e077','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:09'),
	('c335daf0778f4e42978369df192f90d7','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:10'),
	('764717dbb9d4d8ba0435af5e3d329745','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:10'),
	('bed3331a5b287e7a6c3fc62b7c6ac98c','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:11'),
	('f1989a53d57e911050529a6437f8fd47','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:11'),
	('693f81bef98490aacfd112ee1c2fa039','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:11'),
	('9b1b1e59b3f7136c123c403ffe88ecb2','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:12'),
	('426dfb13d2397de56ea58881f7cd8fe2','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:15'),
	('d77000961cb17b15327f1d3ed643ceec','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:15'),
	('a18891ae95ae8705cc863cbc86338326','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:16'),
	('7d92e9c69253b4e9a1fb25eef07a1b31','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:16'),
	('30f268569806e5955f4583be27dc46b1','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:17'),
	('db92fbf047e9d9ffb44fd717808e64d5','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:17'),
	('b0380a1216158a802ee39a9cbc014977','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:17'),
	('48636a52b91b4ae546a2440369b637a5','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:17'),
	('4574de97e885cd0c274cd76cada19f25','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:18'),
	('8e1b82ef45c9fc6c3be887649c351dcd','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:18'),
	('50b9af07ec65aefa94a7a5147ac72f9a','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:19'),
	('822301ddc3b8696024ed29e791660154','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:19'),
	('f6b7bf1d87b60e9942ecc10490f73feb','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:19'),
	('87d87ace34e7813d3782b01e2ba5fa58','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:19'),
	('4d561b61385636025261b7ce0ec1817e','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:20'),
	('119547ff6cea0f34a2fd18ed27bf10bf','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:20'),
	('bdbb6f90dd5463e9a39a57acfb38ca30','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:20'),
	('cb574efa8f3fcc37e383f3c2ee0a9638','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:20'),
	('f732fbd91a2f6e95617a97a80e83b243','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:21'),
	('a748a6db8c83c4326f22c6ce70ad3d24','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:21'),
	('a402aa3af1eb180ef15d16eecde9dba0','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:22'),
	('114b20abff77213522264f4064ecfc06','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:22'),
	('0c47e7c102745dbe2d6a600ba418acbc','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:22'),
	('d5d42cf5525d70fb717c4927e69ce38f','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:22'),
	('3cab76682465f23662a1756062c6c6a5','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:23'),
	('c9f47011ba2368189044c2171f045960','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:23'),
	('2aad21808caec0ca7206865d759c0822','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:23'),
	('12a280818ffde7a0e0973dcc521dd350','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:23'),
	('4dff6b533dde54f162c026e27e7478a1','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:24'),
	('e035788a122bb1a2a8f4ae9a707ac6c7','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:24'),
	('c36baac25592481aa2c8214389b080ed','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:24'),
	('ee90e47dbb4c4e3079232403fee2e82d','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:24'),
	('7c58d4f6f894846dc454340916f676c7','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:24'),
	('e9e0c716cfb1a4ddfe8729600b9ceb80','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:24'),
	('2a63946e6f4e4c420efa4ef79f709fca','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:24'),
	('c6346499ca66e4cbc7344913924b66f7','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:24'),
	('b77d2bc915de8ff8d103b88853706f5d','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:25'),
	('88b61c1d7cb6077a994ebc4cc73051b0','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:25'),
	('bf106b86fee0ae436f65819110833626','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:25'),
	('c42aa16b3d9d984dbbe11b24c8cf1b9f','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:25'),
	('82c74ffd41b04b8852c2c60d9e12c934','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:25'),
	('19906228e165582681fdfa2adc0af7c8','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:25'),
	('afa9599fe5b858499be32e088cfdf13e','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:25'),
	('12ec8708a4e117e34d98bb67f05f87ad','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:26'),
	('131789bae530bc014a90bb080e737737','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:26'),
	('874fa81bb76ae4e65b0223e2f89f0ce4','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:26'),
	('d4e44ffba464492b79dad3e964e05421','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:26'),
	('9d5457bb5b200f0ddeb26c9154b40512','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:26'),
	('eb401a748bcc71fed8865320c6a7dc65','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:26'),
	('0b7d8398bbc23c6f61775f843b4b3ee6','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:26'),
	('dbbf9d7b25789fecab6030c9e083ca44','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:27'),
	('17b90fab766329da3b698bfc5e1ca4a2','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:27'),
	('8faf55ccf81abb29092f1a3ce5829251','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:27'),
	('55d1eb3516f59b9140278cea641db920','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:27'),
	('a8a29e7b80db5e3dbf963c619b3f981a','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:27'),
	('71c3b9bfcd7cefd8cf1776c230907a00','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:27'),
	('2b5b8587f7e85f31c9365919b7823c99','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEJdS4yNzIzZmI1ZDAxMTM1MzQ0\nZWUyZjk3NWIwMzE2OWNmOQ==\n','2010-09-09 12:39:28'),
	('3b07725b350c34986f28f51112027c7d','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEJdS4yNzIzZmI1ZDAxMTM1MzQ0\nZWUyZjk3NWIwMzE2OWNmOQ==\n','2010-09-09 12:39:28'),
	('c4311e9632a165b4b06f38ec870974fe','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEHdS43MjUyNTE5OWRkM2VhOTg1\nYWUwODg1MjAxZjBkOTkxNw==\n','2010-09-09 12:39:28'),
	('d3434ea90cfcb7c6f593e5b00c63e094','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEHdS43MjUyNTE5OWRkM2VhOTg1\nYWUwODg1MjAxZjBkOTkxNw==\n','2010-09-09 12:39:28'),
	('b1a5c8ac59966df52725ccd0982dd5b4','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEGdS5hMDBiYTFmMWJiNWVjYmUy\nYzk0M2M3NGYxOTMzNzA3Ng==\n','2010-09-09 12:39:28'),
	('4b1223f0b9904fcc70aa0d6e4c4ef4b9','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEGdS5hMDBiYTFmMWJiNWVjYmUy\nYzk0M2M3NGYxOTMzNzA3Ng==\n','2010-09-09 12:39:28'),
	('16d914960752748a66e198ed37618682','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEKdS4wYjQwYzBjMDIwNzYyYWU4\nNGEwZjI5M2Y5NTk1MjVhOQ==\n','2010-09-09 12:39:28'),
	('70eed8dedf86445bcebe7740db1793a3','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEKdS4wYjQwYzBjMDIwNzYyYWU4\nNGEwZjI5M2Y5NTk1MjVhOQ==\n','2010-09-09 12:39:28'),
	('6cc3d2b690e71eb12ebc4616d10bb0ad','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEIdS4wY2VkMTI5YTE5MTg2NDhi\nYTFlM2Y0ODQyZTgxNTM5ZA==\n','2010-09-09 12:39:28'),
	('f5d1e5ef53443e2328a322edebc3905c','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEIdS4wY2VkMTI5YTE5MTg2NDhi\nYTFlM2Y0ODQyZTgxNTM5ZA==\n','2010-09-09 12:39:28'),
	('9c9e97f5624790c9c8623bdee70a88ca','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:29'),
	('c9e5e146b7bd7c4e5f7b77b502ecc9ca','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEHdS43MjUyNTE5OWRkM2VhOTg1\nYWUwODg1MjAxZjBkOTkxNw==\n','2010-09-09 12:39:29'),
	('a777db751d9195e8e74357101e3355b8','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEGdS5hMDBiYTFmMWJiNWVjYmUy\nYzk0M2M3NGYxOTMzNzA3Ng==\n','2010-09-09 12:39:30'),
	('aeef51628ff9cfd06d21d2598f747378','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEKdS4wYjQwYzBjMDIwNzYyYWU4\nNGEwZjI5M2Y5NTk1MjVhOQ==\n','2010-09-09 12:39:30'),
	('9de49bc76e2ce3aae047d361454f8da0','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEIdS4wY2VkMTI5YTE5MTg2NDhi\nYTFlM2Y0ODQyZTgxNTM5ZA==\n','2010-09-09 12:39:30'),
	('72dbd188c071bc4b978bdf243054dedf','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:30'),
	('d311037779f32d7329cd7a46f260f3d4','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEHdS43MjUyNTE5OWRkM2VhOTg1\nYWUwODg1MjAxZjBkOTkxNw==\n','2010-09-09 12:39:31'),
	('512f91891c92edea7f0718fe9350c049','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEGdS5hMDBiYTFmMWJiNWVjYmUy\nYzk0M2M3NGYxOTMzNzA3Ng==\n','2010-09-09 12:39:32'),
	('15957ea881e5b4f4ed6f304b391788e8','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEKdS4wYjQwYzBjMDIwNzYyYWU4\nNGEwZjI5M2Y5NTk1MjVhOQ==\n','2010-09-09 12:39:32'),
	('bf355fc9e1fce550c10dccf588588caf','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEIdS4wY2VkMTI5YTE5MTg2NDhi\nYTFlM2Y0ODQyZTgxNTM5ZA==\n','2010-09-09 12:39:33'),
	('9265ef89712f2c2eba327b8eedbae12b','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:33'),
	('5fbdf9825eeecb391490b2d323f4e0fd','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEHdS43MjUyNTE5OWRkM2VhOTg1\nYWUwODg1MjAxZjBkOTkxNw==\n','2010-09-09 12:39:33'),
	('e1e9b78e5c4cce3877871d0b2698ae6f','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:33'),
	('07fab576548e6052399ab11b8d00eef5','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:33'),
	('18a751b2e3645a539938d8450e1e51b9','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:33'),
	('17d16dfa5b73b5b05c260ff75b379031','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:34'),
	('cc6ab53803168f91b0f231961d831a0b','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:34'),
	('caf107cf5335c0b3ba4ca9e47672e33a','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:34'),
	('e74790f17986122c19e378625d33e3d5','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEHdS43MjUyNTE5OWRkM2VhOTg1\nYWUwODg1MjAxZjBkOTkxNw==\n','2010-09-09 12:39:34'),
	('43bb109360ffed7020d2b844dd9d1c7d','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEGdS5hMDBiYTFmMWJiNWVjYmUy\nYzk0M2M3NGYxOTMzNzA3Ng==\n','2010-09-09 12:39:34'),
	('7998b4fcdbe27ddec8aeb88c10ab77ca','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEKdS4wYjQwYzBjMDIwNzYyYWU4\nNGEwZjI5M2Y5NTk1MjVhOQ==\n','2010-09-09 12:39:34'),
	('46b8b8fae5795a980936b89252cae1c0','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEIdS4wY2VkMTI5YTE5MTg2NDhi\nYTFlM2Y0ODQyZTgxNTM5ZA==\n','2010-09-09 12:39:34'),
	('d8159b2eddfd983eba9c87433c9074d5','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:34'),
	('9f573d7295f32f7b47d0f0d940f0c306','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:34'),
	('77c56c3cf82d85d98829c87c472f6cae','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:34'),
	('cc105f0c8d4c78fe888c457d83339559','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:34'),
	('8389fab5885db88f2e1ded84fe3bf8f8','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:34'),
	('95c9f6b475d73953e7c8d33480acaa0f','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:34'),
	('678747e9bdc33df06f173b60be1ec942','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:34'),
	('308c58a2570b0aaeda12b725393a5c81','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:34'),
	('36710264b5dcd1fcc93ad9a51d327d0d','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:34'),
	('a8343b03ab1d1d867dddd75c77343ab8','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:34'),
	('7daf8b26c0b6266663568bd14f790eed','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:34'),
	('f53792615847371b3d39976e83a2c011','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:34'),
	('d0f707b950832000e292a15fae499917','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEHdS43MjUyNTE5OWRkM2VhOTg1\nYWUwODg1MjAxZjBkOTkxNw==\n','2010-09-09 12:39:34'),
	('67772b3c33449df901154649ee148962','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEGdS5hMDBiYTFmMWJiNWVjYmUy\nYzk0M2M3NGYxOTMzNzA3Ng==\n','2010-09-09 12:39:34'),
	('2390dd4f51a855df65c8c4fee0a640f6','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEKdS4wYjQwYzBjMDIwNzYyYWU4\nNGEwZjI5M2Y5NTk1MjVhOQ==\n','2010-09-09 12:39:35'),
	('e1dd2fd6bcd57d0ffc1df287c206b813','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEIdS4wY2VkMTI5YTE5MTg2NDhi\nYTFlM2Y0ODQyZTgxNTM5ZA==\n','2010-09-09 12:39:35'),
	('62f3389177176abfbc03d084d3c8f3b3','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:36'),
	('a1e0173a844c29b302fb7f8d5d4d99e7','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEIdS4wY2VkMTI5YTE5MTg2NDhi\nYTFlM2Y0ODQyZTgxNTM5ZA==\n','2010-09-09 12:39:36'),
	('fe2a7dc06800238effa9f98a34eabd9e','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:37'),
	('0a6186ef02fb0304263a36d381fe47b2','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:37'),
	('fd5083a4d8c3adaefad139da1097d6b9','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:37'),
	('91039423692d8e289a2efc18c7c49c10','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:37'),
	('9237cc2b51905d35a6ae341564f30750','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:37'),
	('6479531ee33662e3e8d170bd1506c457','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:37'),
	('cd006658f5a34172f03c451a69d1362c','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEJdS4yNzIzZmI1ZDAxMTM1MzQ0\nZWUyZjk3NWIwMzE2OWNmOQ==\n','2010-09-09 12:39:39'),
	('16eb4dcc55640ef8c99fae5dce29c60c','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEJdS4yNzIzZmI1ZDAxMTM1MzQ0\nZWUyZjk3NWIwMzE2OWNmOQ==\n','2010-09-09 12:39:39'),
	('0b744ae0d3355b3ffcf4c27769d008a6','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:39'),
	('513f13d9466fdc0c15cca9fe2e5d506a','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEHdS43MjUyNTE5OWRkM2VhOTg1\nYWUwODg1MjAxZjBkOTkxNw==\n','2010-09-09 12:39:39'),
	('10ecc92f8651282c67820fabff59d487','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEGdS5hMDBiYTFmMWJiNWVjYmUy\nYzk0M2M3NGYxOTMzNzA3Ng==\n','2010-09-09 12:39:39'),
	('a31a9e5c6e22fb2177a28ec9f9679314','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEKdS4wYjQwYzBjMDIwNzYyYWU4\nNGEwZjI5M2Y5NTk1MjVhOQ==\n','2010-09-09 12:39:39'),
	('dbf1218cfcfa4771a2db205a300e6cef','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEIdS4wY2VkMTI5YTE5MTg2NDhi\nYTFlM2Y0ODQyZTgxNTM5ZA==\n','2010-09-09 12:39:40'),
	('d6a78fb73fbf9fee0cd91610e3fb8a7f','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:40'),
	('12ad5d7a9e41895f43c01641bc8c3322','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:40'),
	('3428a76ddebf7bff6bf7b46edd983b3c','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:40'),
	('8d73e9c4f89bfa1aec2517d2a294df44','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:40'),
	('308ca0d3a55a92257cee0ca9e43bec25','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:40'),
	('7704f9dcfb437e029c6feb552c218b5c','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:40'),
	('3974be5f963cfd29a968efb78697a264','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:40'),
	('2fc304a660bbb17a6d845a32dd1fbf27','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigECdS4xOWJhYTUwOWQ0ODU3MDhk\nYTY0NDZjOTNlNzVhZGMxMQ==\n','2010-09-09 12:39:40'),
	('3e0e204e5e21fbf2a6bff130510a9dd2','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigECdS4xOWJhYTUwOWQ0ODU3MDhk\nYTY0NDZjOTNlNzVhZGMxMQ==\n','2010-09-09 12:39:40'),
	('fd4f600cf3016207ec5954eda79e190e','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigECdS4xOWJhYTUwOWQ0ODU3MDhk\nYTY0NDZjOTNlNzVhZGMxMQ==\n','2010-09-09 12:39:40'),
	('cb0466336288b8cb71a528c49000efd9','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigECdS4xOWJhYTUwOWQ0ODU3MDhk\nYTY0NDZjOTNlNzVhZGMxMQ==\n','2010-09-09 12:39:40'),
	('6f3966d269033e088f71d6b2ae540264','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigECdS4xOWJhYTUwOWQ0ODU3MDhk\nYTY0NDZjOTNlNzVhZGMxMQ==\n','2010-09-09 12:39:40'),
	('9f48cfaacd086bf9398940077a0e1c82','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigECdS4xOWJhYTUwOWQ0ODU3MDhk\nYTY0NDZjOTNlNzVhZGMxMQ==\n','2010-09-09 12:39:40'),
	('5ae07625bedffba2ac13eeff1d6328eb','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigECdS4xOWJhYTUwOWQ0ODU3MDhk\nYTY0NDZjOTNlNzVhZGMxMQ==\n','2010-09-09 12:39:40'),
	('0c4f6ac4305501ea159379e17fcdaece','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigECdS4xOWJhYTUwOWQ0ODU3MDhk\nYTY0NDZjOTNlNzVhZGMxMQ==\n','2010-09-09 12:39:40'),
	('fcb5183ca84f2e297365914eb5e0c535','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigECdS4xOWJhYTUwOWQ0ODU3MDhk\nYTY0NDZjOTNlNzVhZGMxMQ==\n','2010-09-09 12:39:40'),
	('619b720cc4d84665c7f026c8f3a46160','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:41'),
	('eed33a0d071e728268c321632ba710b2','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:41'),
	('2c3799526a45e7a88960322569b66e64','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:41'),
	('c46e1e827d80574075ea6406844c69c9','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:41'),
	('9ae1bcbaa8dee39b4de1007a37fea9e1','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:41'),
	('d2b57a763a70018d65c135de85eebd5a','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:41'),
	('49d370ab5d0f5908e971e5a4223ab480','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:41'),
	('67a21e43f6e7e0f8b8c2d58f84b462b1','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:42'),
	('25a83fb060384b9d162f305192098007','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:42'),
	('f49c01bc98c616f060ee93b0bdc6a49c','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:42'),
	('e66bc0ad38998ea9c30bf5b5f8ba540b','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEIdS4wY2VkMTI5YTE5MTg2NDhi\nYTFlM2Y0ODQyZTgxNTM5ZA==\n','2010-09-09 12:39:42'),
	('3c051740f08daa897d836e5253d3f2ef','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEIdS4wY2VkMTI5YTE5MTg2NDhi\nYTFlM2Y0ODQyZTgxNTM5ZA==\n','2010-09-09 12:39:42'),
	('7703fc21d172ad332063d6a48a06e236','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:42'),
	('d5bb6b36031d5923aab43f4b00c3b1f6','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:42'),
	('262d49009a04ee743388ee387932508c','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:43'),
	('7fbe770b2918bbacd40d65fd1471c03e','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEIdS4wY2VkMTI5YTE5MTg2NDhi\nYTFlM2Y0ODQyZTgxNTM5ZA==\n','2010-09-09 12:39:43'),
	('c47c510574f628c37b91862b23e9d859','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:43'),
	('0199ece6900a3bf0131e3f7a56fc26a0','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:44'),
	('34112ac6689a7a1c33f0e7d0b9434cee','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:44'),
	('44a36e88c6e7c465d0b33754ac3ae08a','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:44'),
	('ebe3cc20853c47e3768ca9195628d667','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:44'),
	('9c6b51f0dcb141da07fe52b35ae8d4cc','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEIdS4wY2VkMTI5YTE5MTg2NDhi\nYTFlM2Y0ODQyZTgxNTM5ZA==\n','2010-09-09 12:39:44'),
	('c7ac1a2586710b89b737b870ef81b2fb','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:44'),
	('e9911560e1f23e415324bdfebd58e944','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEIdS4wY2VkMTI5YTE5MTg2NDhi\nYTFlM2Y0ODQyZTgxNTM5ZA==\n','2010-09-09 12:39:44'),
	('ce73c3f4910908c007a9d1fb68752b9e','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:44'),
	('7eacdb6af331826a4060c99c03eb6438','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:44'),
	('97fc66753beebc46ebb12c652f5eb2b4','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:44'),
	('3cd048ffaa312b72cce58c411ea25aad','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:45'),
	('8a411872614f5650daf2bcfa3519c8b9','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEIdS4wY2VkMTI5YTE5MTg2NDhi\nYTFlM2Y0ODQyZTgxNTM5ZA==\n','2010-09-09 12:39:45'),
	('c1e43975837951381a473da65eecf240','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:45'),
	('e6b111ba73c4c525f23ee2b216364378','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEFdS41MTY3MmY0OGE4OTNmYzM0\nMWIyZTEzMTFmYTRkODdhYQ==\n','2010-09-09 12:39:45'),
	('7295f9c464c1f927c441f89e01e558cd','gAJ9cQEoVRJfYXV0aF91c2VyX2JhY2tlbmRxAlUsZHljYXBvLmF1dGhfYmFja2VuZHMuRHljYXBv\nUmVtb3RlVXNlckJhY2tlbmRxA1UNX2F1dGhfdXNlcl9pZHEEigEEdS4xYjNkMGFkM2EwOWU1NDRi\nNGVlNjc3N2Y4YWY4MzRkMg==\n','2010-09-09 12:39:45');

/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table django_site
# ------------------------------------------------------------

DROP TABLE IF EXISTS `django_site`;

CREATE TABLE `django_site` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

LOCK TABLES `django_site` WRITE;
/*!40000 ALTER TABLE `django_site` DISABLE KEYS */;
INSERT INTO `django_site` (`id`,`domain`,`name`)
VALUES
	(1,'example.com','example.com');

/*!40000 ALTER TABLE `django_site` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table piston_consumer
# ------------------------------------------------------------

DROP TABLE IF EXISTS `piston_consumer`;

CREATE TABLE `piston_consumer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `key` varchar(18) NOT NULL,
  `secret` varchar(32) NOT NULL,
  `status` varchar(16) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `piston_consumer_fbfc09f1` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table piston_nonce
# ------------------------------------------------------------

DROP TABLE IF EXISTS `piston_nonce`;

CREATE TABLE `piston_nonce` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token_key` varchar(18) NOT NULL,
  `consumer_key` varchar(18) NOT NULL,
  `key` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table piston_token
# ------------------------------------------------------------

DROP TABLE IF EXISTS `piston_token`;

CREATE TABLE `piston_token` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(18) NOT NULL,
  `secret` varchar(32) NOT NULL,
  `verifier` varchar(10) NOT NULL,
  `token_type` int(11) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `is_approved` tinyint(1) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `consumer_id` int(11) NOT NULL,
  `callback` varchar(255) DEFAULT NULL,
  `callback_confirmed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `piston_token_fbfc09f1` (`user_id`),
  KEY `piston_token_6565fc20` (`consumer_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table server_location
# ------------------------------------------------------------

DROP TABLE IF EXISTS `server_location`;

CREATE TABLE `server_location` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(255) NOT NULL,
  `street` varchar(255) NOT NULL,
  `point` varchar(50) NOT NULL,
  `country` varchar(2) NOT NULL,
  `region` varchar(255) NOT NULL,
  `town` varchar(255) NOT NULL,
  `postcode` int(10) unsigned NOT NULL,
  `subregion` varchar(255) NOT NULL,
  `georss_point` varchar(255) NOT NULL,
  `georss_point_latitude` double NOT NULL,
  `georss_point_longitude` double NOT NULL,
  `offset` int(10) unsigned NOT NULL,
  `recurs` varchar(255) NOT NULL,
  `days` varchar(255) NOT NULL,
  `leaves` datetime NOT NULL,
  `href` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `server_location_fa8e2538` (`point`),
  KEY `server_location_e2a5c0f` (`georss_point`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table server_modality
# ------------------------------------------------------------

DROP TABLE IF EXISTS `server_modality`;

CREATE TABLE `server_modality` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kind` varchar(255) NOT NULL,
  `capacity` int(10) unsigned NOT NULL,
  `vacancy` int(11) NOT NULL,
  `make` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `year` int(10) unsigned NOT NULL,
  `color` varchar(255) NOT NULL,
  `lic` varchar(255) NOT NULL,
  `cost` double NOT NULL,
  `person_id` int(11) DEFAULT NULL,
  `href` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `server_modality_21b911c5` (`person_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table server_participation
# ------------------------------------------------------------

DROP TABLE IF EXISTS `server_participation`;

CREATE TABLE `server_participation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `person_id` int(11) NOT NULL,
  `trip_id` int(11) NOT NULL,
  `role` varchar(6) NOT NULL,
  `requested` tinyint(1) NOT NULL,
  `requested_timestamp` datetime DEFAULT NULL,
  `requested_position_id` int(11) DEFAULT NULL,
  `requested_deleted` tinyint(1) NOT NULL,
  `requested_deleted_timestamp` datetime DEFAULT NULL,
  `requested_deleted_position_id` int(11) DEFAULT NULL,
  `accepted` tinyint(1) NOT NULL,
  `accepted_timestamp` datetime DEFAULT NULL,
  `accepted_position_id` int(11) DEFAULT NULL,
  `refused` tinyint(1) NOT NULL,
  `refused_timestamp` datetime DEFAULT NULL,
  `refused_position_id` int(11) DEFAULT NULL,
  `started` tinyint(1) NOT NULL,
  `started_timestamp` datetime DEFAULT NULL,
  `started_position_id` int(11) DEFAULT NULL,
  `finished` tinyint(1) NOT NULL,
  `finished_timestamp` datetime DEFAULT NULL,
  `finished_position_id` int(11) DEFAULT NULL,
  `href` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `person_id` (`person_id`,`trip_id`),
  KEY `server_participation_21b911c5` (`person_id`),
  KEY `server_participation_ab5488a7` (`trip_id`),
  KEY `server_participation_6d876e44` (`requested_position_id`),
  KEY `server_participation_2140776e` (`requested_deleted_position_id`),
  KEY `server_participation_f0424aca` (`accepted_position_id`),
  KEY `server_participation_ead8a8be` (`refused_position_id`),
  KEY `server_participation_624bc54d` (`started_position_id`),
  KEY `server_participation_9edd96f9` (`finished_position_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table server_participation_locations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `server_participation_locations`;

CREATE TABLE `server_participation_locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `participation_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `participation_id` (`participation_id`,`location_id`),
  KEY `server_participation_locations_3c980c0e` (`participation_id`),
  KEY `server_participation_locations_319d859` (`location_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table server_person
# ------------------------------------------------------------

DROP TABLE IF EXISTS `server_person`;

CREATE TABLE `server_person` (
  `user_ptr_id` int(11) NOT NULL,
  `uri` varchar(200) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `position_id` int(11) DEFAULT NULL,
  `age` int(10) unsigned NOT NULL,
  `gender` varchar(1) NOT NULL,
  `smoker` tinyint(1) NOT NULL,
  `blind` tinyint(1) NOT NULL,
  `deaf` tinyint(1) NOT NULL,
  `dog` tinyint(1) NOT NULL,
  `href` varchar(200) NOT NULL,
  PRIMARY KEY (`user_ptr_id`),
  UNIQUE KEY `phone` (`phone`),
  KEY `server_person_80180135` (`position_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

LOCK TABLES `server_person` WRITE;
/*!40000 ALTER TABLE `server_person` DISABLE KEYS */;
INSERT INTO `server_person` (`user_ptr_id`,`uri`,`phone`,`position_id`,`age`,`gender`,`smoker`,`blind`,`deaf`,`dog`,`href`)
VALUES
	(2,'http://dycapo.org','123123123123123123',NULL,99,'M',0,0,0,0,''),
	(3,'','12345',NULL,0,'M',0,0,0,0,''),
	(4,'','123456',NULL,0,'M',0,0,0,0,''),
	(5,'','1234567',NULL,0,'M',0,0,0,0,''),
	(6,'','12345678',NULL,0,'M',0,0,0,0,''),
	(7,'','123456789',NULL,0,'M',0,0,0,0,''),
	(8,'','1234567890',NULL,0,'M',0,0,0,0,''),
	(9,'','1234567801324',NULL,0,'M',0,0,0,0,''),
	(10,'','12345678901',NULL,0,'F',0,0,0,0,'');

/*!40000 ALTER TABLE `server_person` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table server_person_locations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `server_person_locations`;

CREATE TABLE `server_person_locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `person_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `person_id` (`person_id`,`location_id`),
  KEY `server_person_locations_21b911c5` (`person_id`),
  KEY `server_person_locations_319d859` (`location_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table server_preferences
# ------------------------------------------------------------

DROP TABLE IF EXISTS `server_preferences`;

CREATE TABLE `server_preferences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `age` varchar(50) NOT NULL,
  `nonsmoking` tinyint(1) NOT NULL,
  `gender` varchar(1) NOT NULL,
  `drive` tinyint(1) NOT NULL,
  `ride` tinyint(1) NOT NULL,
  `href` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table server_trip
# ------------------------------------------------------------

DROP TABLE IF EXISTS `server_trip`;

CREATE TABLE `server_trip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `published` datetime NOT NULL,
  `updated` datetime NOT NULL,
  `expires` datetime DEFAULT NULL,
  `active` tinyint(1) NOT NULL,
  `author_id` int(11) NOT NULL,
  `modality_id` int(11) NOT NULL,
  `preferences_id` int(11) NOT NULL,
  `href` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `server_trip_87f258d4` (`expires`),
  KEY `server_trip_34d728db` (`active`),
  KEY `server_trip_cc846901` (`author_id`),
  KEY `server_trip_117d78a1` (`modality_id`),
  KEY `server_trip_2d9474d5` (`preferences_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table server_trip_locations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `server_trip_locations`;

CREATE TABLE `server_trip_locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `trip_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `trip_id` (`trip_id`,`location_id`),
  KEY `server_trip_locations_ab5488a7` (`trip_id`),
  KEY `server_trip_locations_319d859` (`location_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;






/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
